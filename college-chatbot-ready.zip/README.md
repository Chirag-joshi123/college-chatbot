
# AI Chatbot for College Enquiry

Python Flask-based AI chatbot to answer college-related queries.

## How to Run
pip install -r requirements.txt
python app.py

Open http://127.0.0.1:5000/
