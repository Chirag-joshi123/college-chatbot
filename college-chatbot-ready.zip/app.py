
from flask import Flask, render_template, request, jsonify
import json
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)

with open('college_data.json', 'r') as f:
    data = json.load(f)

questions = []
answers = []

for intent in data['intents']:
    for q in intent['questions']:
        questions.append(q)
        answers.append(intent['answers'])

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(questions)

model = LogisticRegression(max_iter=1000)
model.fit(X, answers)

def chatbot_response(user_input):
    vec = vectorizer.transform([user_input.lower()])
    response_list = model.predict(vec)[0]
    return random.choice(response_list)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get', methods=['POST'])
def get_bot_response():
    user_msg = request.form['msg']
    reply = chatbot_response(user_msg)
    return jsonify({'reply': reply})

if __name__ == '__main__':
    app.run(debug=True)
